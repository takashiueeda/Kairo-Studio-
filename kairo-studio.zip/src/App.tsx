/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { Differentials } from './components/Differentials';
import { Testimonials } from './components/Testimonials';
import { BudgetSimulator } from './components/BudgetSimulator';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  const scrollToContact = () => {
    const el = document.getElementById('contato');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex flex-col selection:bg-neutral-200 selection:text-neutral-950">
      {/* Navigation Top Bar Contract */}
      <Navbar onOpenBudgetModal={scrollToContact} />

      <main className="flex-1">
        {/* Seção Inicial Impactante */}
        <Hero />

        {/* Conheça a Kairo Studio */}
        <About />

        {/* Serviços */}
        <Services />

        {/* Portfólio / Projetos Selecionados */}
        <Portfolio />

        {/* Diferenciais Competitivos: Entrega no Mesmo Dia & Custo-Benefício */}
        <Differentials />

        {/* Depoimentos & Casos Reais de Clientes */}
        <Testimonials />

        {/* Simulador Interativo de Orçamento */}
        <BudgetSimulator />

        {/* Formulário de Contato & Canais Diretos */}
        <Contact />
      </main>

      {/* Footer Minimalista */}
      <Footer />

      {/* WhatsApp Flutuante com Micro-Janela de Contato */}
      <FloatingWhatsApp />
    </div>
  );
}
