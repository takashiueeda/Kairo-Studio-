import { Project, Service, Testimonial } from '../types';

export const STUDIO_CONFIG = {
  brandName: 'Kairo Studio',
  tagline: 'Sua presença digital começa com um site extraordinário',
  whatsappNumber: '+5598988697699',
  whatsappClean: '5598988697699',
  instagram: '@kairotechnologystudio',
  instagramUrl: 'https://instagram.com/kairotechnologystudio',
  email: 'contato@kairo-studio.com',
  location: 'Brasil · Atendimento 100% Online',
  primaryDifferentiators: [
    { title: 'Entrega no mesmo dia', desc: 'Opção express para colocar sua empresa no ar em até 24 horas' },
    { title: 'Excelente custo-benefício', desc: 'Padrão visual de grande agência sem orçamentos exorbitantes' },
    { title: 'Foco em faturamento', desc: 'Páginas desenvolvidas para transformar cliques em clientes no WhatsApp' },
  ],
  aboutStory: {
    lead: 'Atuamos na criação de sites há 6 meses, transformando ideias em soluções digitais modernas, funcionais e profissionais.',
    paragraphs: [
      'Estamos construindo nossa trajetória no mercado de tecnologia com dedicação, criatividade e vontade constante de evoluir. Nosso objetivo é ajudar empresas, empreendedores e profissionais a fortalecerem sua presença digital, conquistarem mais visibilidade e transmitirem credibilidade na internet.',
      'Acreditamos que todo negócio merece uma presença online de qualidade. Por isso, buscamos desenvolver projetos que unam design, tecnologia e praticidade, sempre valorizando as necessidades de cada cliente.',
      'A Kairo Studio está pronta para transformar sua ideia em realidade e construir algo incrível juntos!'
    ],
    experienceYears: '6 meses',
    status: 'Disponível para novos projetos hoje',
  }
};

export const getWhatsAppUrl = (customMessage?: string) => {
  const defaultText = encodeURIComponent(
    'Olá! Vi o portfólio da Kairo Studio e gostaria de solicitar um orçamento para o meu site.'
  );
  const msg = customMessage ? encodeURIComponent(customMessage) : defaultText;
  return `https://wa.me/${STUDIO_CONFIG.whatsappClean}?text=${msg}`;
};

import clinicImg from '../assets/images/project_luxury_clinic_1794399895289.jpg';
import corporateImg from '../assets/images/project_corporate_office_1794399895116.jpg';
import jewelryImg from '../assets/images/project_luxury_jewelry_1794399895598.jpg';

export const PROJECTS: Project[] = [
  {
    id: 'aethel-clinic',
    title: 'Clínica Aethel Médica',
    niche: 'Saúde & Medicina Integrativa',
    client: 'Aethel Longevity & Clinic',
    tagline: 'Landing Page de Alta Conversão para captação de pacientes particulares',
    description: 'Interface sofisticada com foco em experiência mobile e agendamento instantâneo. Desenvolvido para transmitir autoridade clínica, segurança e excelência médica desde os primeiros 3 segundos de navegação.',
    deliveryTime: 'Entrega em 24h',
    metric: '+185%',
    metricLabel: 'Novos contatos no WhatsApp',
    image: clinicImg,
    features: [
      'Design minimalista de alto padrão',
      'Agendamento direto integrado ao WhatsApp',
      'Carregamento ultra-rápido (< 0.8s)',
      'Otimizado para anúncios no Google Ads'
    ],
    year: '2026'
  },
  {
    id: 'silver-oak',
    title: 'Silver Oak Advisory & Law',
    niche: 'Direito Corporativo & Finanças',
    client: 'Silver Oak Strategic Legal',
    tagline: 'Site institucional sóbrio para fechamento de contratos de alto ticket',
    description: 'Desenvolvimento corporativo focado em transmitir credibilidade inabalável e solidez para investidores e diretores de empresas. Paleta sóbria em preto, prata escovada e tipografia precisa.',
    deliveryTime: 'Entrega no mesmo dia',
    metric: 'R$ 480k',
    metricLabel: 'Em propostas fechadas via site',
    image: corporateImg,
    features: [
      'Hierarquia visual executiva',
      'Formulário qualificado de proposta',
      'Páginas de áreas de atuação estratégica',
      '100% responsivo para celulares e tablets'
    ],
    year: '2026'
  },
  {
    id: 'aurelien-paris',
    title: 'Aurélien Joalheria & Estilo',
    niche: 'Moda & Produtos Exclusivos',
    client: 'Aurélien Brand',
    tagline: 'Catálogo digital minimalista com fechamento ágil de vendas',
    description: 'Experiência de e-commerce e catálogo de apresentação com visual de luxo. Cada produto possui botão direto para negociação e compra rápida pelo WhatsApp, eliminando atritos no checkout.',
    deliveryTime: 'Entrega em 48h',
    metric: '3.4x',
    metricLabel: 'Mais pedidos diretos no WhatsApp',
    image: jewelryImg,
    features: [
      'Fotografia com destaque editorial',
      'Botão de compra instantânea em cada item',
      'Navegação fluida sem travamentos',
      'Excelente custo-benefício para marcas'
    ],
    year: '2026'
  }
];

export const SERVICES: Service[] = [
  {
    id: 'landing-pages',
    number: '01',
    title: 'Landing Pages de Alta Conversão',
    shortDesc: 'Páginas estratégicas projetadas para transformar visitantes e cliques de anúncios em dinheiro no caixa.',
    fullDesc: 'Construídas com copywriting persuasivo, hierarquia visual magnética e chamadas claras para ação no WhatsApp. Perfeitas para prestadores de serviço, clínicas, infoprodutos e empresas locais.',
    highlight: 'Ideal para tráfego pago',
    idealFor: 'Empresas que anunciam no Google, Instagram ou Facebook',
    timeline: 'Entrega rápida ou no mesmo dia',
    features: [
      'Copywriting comercial voltado para fechamento',
      'Integração direta com WhatsApp e e-mail',
      'Design exclusivo que passa confiança imediata',
      'Velocidade máxima no mobile (Google PageSpeed 90+)'
    ]
  },
  {
    id: 'sites-institucionais',
    number: '02',
    title: 'Sites Institucionais de Autoridade',
    shortDesc: 'A vitrine definitiva do seu negócio para transmitir credibilidade, fechar contratos maiores e valorizar sua marca.',
    fullDesc: 'Um site institucional de alto padrão separa a sua empresa dos amadores. Estruturamos quem você é, seus diferenciais e seus serviços com um acabamento limpo em preto, prata e branco.',
    highlight: 'Posicionamento premium',
    idealFor: 'Empresas, escritórios e consultorias que buscam autoridade',
    timeline: 'De 24h a 48h de produção',
    features: [
      'Estrutura com seções Sobre, Serviços, Portfólio e Contato',
      'Otimizado para buscas no Google (SEO estruturado)',
      'Design moderno com muito respiro e elegância',
      'Sem mensalidades abusivas de manutenção'
    ]
  },
  {
    id: 'site-express',
    number: '03',
    title: 'Site Express (Entrega no Mesmo Dia)',
    shortDesc: 'Precisa do seu site no ar hoje? Nosso processo ágil coloca sua empresa na internet em até 24 horas.',
    fullDesc: 'Eliminamos semanas de reuniões inúteis. Com o método express do Kairo Studio, você nos envia as informações essenciais e nós estruturamos, programamos e publicamos sua presença digital no mesmo dia.',
    highlight: 'Diferencial exclusivo',
    idealFor: 'Quem tem pressa de vender ou lançamento iminente',
    timeline: 'No ar em até 24 horas',
    features: [
      'Prioridade total de desenvolvimento na fila',
      'Setup de domínio e hospedagem sem complicação',
      'Revisão direta pelo WhatsApp com resposta imediata',
      'Qualidade estética impecável mantida'
    ]
  },
  {
    id: 'catalogos-vendas',
    number: '04',
    title: 'Catálogos & Vitrines Digitais',
    shortDesc: 'Apresente seus produtos e serviços em um formato limpo, moderno e com link de pedido direto para o seu WhatsApp.',
    fullDesc: 'Ideal para lojas, fábricas, ateliês e representantes comerciais que querem que o cliente veja fotos, descrições e preços, clicando em "Pedir pelo WhatsApp" para fechar a compra sem burocracia.',
    highlight: 'Vendas sem fricção',
    idealFor: 'Varejo, distribuidoras, marcas e profissionais autônomos',
    timeline: 'De 24h a 48h',
    features: [
      'Listagem clara de produtos ou cardápios/serviços',
      'Botões de contato com mensagem pré-preenchida do item',
      'Design ultra-leve que carrega instantaneamente no 4G/5G',
      'Fácil de atualizar e gerenciar'
    ]
  },
  {
    id: 'otimizacao-redesign',
    number: '05',
    title: 'Redesign & Otimização de Performance',
    shortDesc: 'Seu site atual é lento, feio ou não gera vendas? Transformamos sua página em uma máquina moderna de conversão.',
    fullDesc: 'Mais de 53% dos clientes abandonam um site se ele demorar mais de 3 segundos para carregar. Reformulamos o visual, limpamos o código e reposicionamos sua marca com estética moderna.',
    highlight: 'Recupere clientes perdidos',
    idealFor: 'Negócios com sites antigos que não convertem',
    timeline: 'Entrega ágil em 24h',
    features: [
      'Análise completa de gargalos de conversão',
      'Repaginação visual para o padrão minimalista moderno',
      'Aceleração extrema de tempo de resposta',
      'Migração segura sem tirar seu site do ar'
    ]
  }
];
export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Dr. Marcelo Albuquerque',
    role: 'Diretor Clínico',
    company: 'Clínica Aethel Longevity',
    niche: 'Saúde & Medicina Integrativa',
    quote: 'Precisávamos colocar a página no ar para uma campanha de urgência da nossa nova unidade. Escolhemos o Fast-Track da Kairo Studio e o site estava funcionando no mesmo dia! O retorno foi imediato: na primeira semana recebemos 24 novos agendamentos diretos pelo WhatsApp. O investimento se pagou no primeiro dia.',
    metric: '24 novos agendamentos',
    metricContext: 'Na 1ª semana de campanha',
    city: 'São Paulo, SP',
    speed: 'Entrega no Mesmo Dia (Fast-Track)'
  },
  {
    id: '2',
    name: 'Renata Vasconcellos',
    role: 'Sócia-Fundadora',
    company: 'Aurélien Joias & Conceito',
    niche: 'E-commerce & Acessórios',
    quote: 'Estava cansada de orçamentos de agências pedindo mais de R$ 5.000 e 40 dias de prazo. Na Kairo Studio fechei o Site Essencial com entrega em 48h. O site ficou sofisticado, minimalista em tons de preto e prata, e nossos clientes compram direto pelo WhatsApp. Triplicou nossos pedidos semanais!',
    metric: '3.4x mais pedidos',
    metricContext: 'Fechamentos diretos no WhatsApp',
    city: 'Belo Horizonte, MG',
    speed: 'Entregue em 48 horas (Ágil)'
  },
  {
    id: '3',
    name: 'Carlos Eduardo Fontes',
    role: 'Sócio & Consultor Sênior',
    company: 'Silver Oak Advisory & Law',
    niche: 'Direito & Finanças Corporativas',
    quote: 'No mercado corporativo, um site amador destrói qualquer negociação de alto valor. A Kairo Studio entendeu perfeitamente a seriedade e a sofisticação que precisávamos. O site transmite uma solidez enorme e já nos ajudou a fechar contratos estratégicos de alto ticket.',
    metric: 'R$ 480k em propostas',
    metricContext: 'Geradas através do site',
    city: 'Curitiba, PR',
    speed: 'Site Institucional Premium'
  },
  {
    id: '4',
    name: 'Matheus Guimarães',
    role: 'Proprietário & Engenheiro',
    company: 'Guimarães Engenharia & Reformas',
    niche: 'Engenharia Civil & Construção',
    quote: 'Comecei com o Site Simples de R$ 150 porque precisava validar anúncios locais com rapidez. Em menos de 24 horas o site estava online e impecável no celular. Em 3 dias fechei dois projetos de reforma residencial. O melhor custo-benefício que já encontrei na internet.',
    metric: '2 contratos fechados',
    metricContext: 'Em apenas 3 dias de veiculação',
    city: 'São Luís, MA',
    speed: 'Site Simples (24h)'
  }
];

export const COMPARISON_POINTS = [
  {
    criteria: 'Prazo de Entrega',
    traditionalAgency: '30 a 60 dias úteis com semanas de espera',
    kairoStudio: 'Entrega no mesmo dia (24h) ou em até 48h',
    isWinner: true,
  },
  {
    criteria: 'Custo & Investimento',
    traditionalAgency: 'Valores inflados para sustentar equipe e estruturas caras',
    kairoStudio: 'Excelente custo-benefício, direto com o desenvolvedor',
    isWinner: true,
  },
  {
    criteria: 'Comunicação',
    traditionalAgency: 'Intermediários, gerentes de conta e e-mails lentos',
    kairoStudio: 'WhatsApp direto com quem programa seu site',
    isWinner: true,
  },
  {
    criteria: 'Objetivo do Site',
    traditionalAgency: 'Muitas vezes focado apenas em estética sem conversão',
    kairoStudio: 'Desenvolvido especificamente para aumentar seu faturamento',
    isWinner: true,
  },
  {
    criteria: 'Velocidade no Mobile',
    traditionalAgency: 'Plataformas pesadas que demoram para abrir no celular',
    kairoStudio: 'Código limpo, leve e moderno com abertura instantânea',
    isWinner: true,
  }
];
