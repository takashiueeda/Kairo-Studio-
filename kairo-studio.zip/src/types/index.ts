export interface Project {
  id: string;
  title: string;
  niche: string;
  client: string;
  tagline: string;
  description: string;
  deliveryTime: string;
  metric: string;
  metricLabel: string;
  image: string;
  features: string[];
  year: string;
}

export interface Service {
  id: string;
  number: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  highlight: string;
  idealFor: string;
  timeline: string;
  features: string[];
}
export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  niche: string;
  quote: string;
  metric: string;
  metricContext: string;
  city: string;
  speed: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  company: string;
  projectType: string;
  urgency: string;
  message: string;
}
