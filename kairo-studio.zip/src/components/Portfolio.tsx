import React, { useState } from 'react';
import { PROJECTS, getWhatsAppUrl } from '../data/portfolioData';
import { Project } from '../types';
import { ProjectModal } from './ProjectModal';
import { ArrowUpRight, ExternalLink, Sparkles, Eye } from 'lucide-react';

export const Portfolio: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<string>('todos');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const categories = [
    { id: 'todos', label: 'Todos os Projetos' },
    { id: 'saude', label: 'Saúde & Clínicas' },
    { id: 'corporativo', label: 'Corporativo & Jurídico' },
    { id: 'ecommerce', label: 'Varejo & Produtos' },
  ];

  const filteredProjects = PROJECTS.filter((p) => {
    if (activeFilter === 'todos') return true;
    if (activeFilter === 'saude') return p.niche.includes('Saúde');
    if (activeFilter === 'corporativo') return p.niche.includes('Direito') || p.niche.includes('Finanças');
    if (activeFilter === 'ecommerce') return p.niche.includes('Moda') || p.niche.includes('Produtos');
    return true;
  });

  return (
    <section id="portfolio" className="py-20 md:py-28 border-b border-white/10 bg-[#09090b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
              <span>Portfólio Selecionado</span>
              <span aria-hidden="true">·</span>
              <span>Casos de Sucesso em Diversos Nichos</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white max-w-2xl text-balance">
              Projetos reais com estética moderna e foco em conversão
            </h2>
          </div>

          {/* Interactive Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-white/5 border border-white/10 rounded-lg">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveFilter(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  activeFilter === cat.id
                    ? 'bg-white text-black font-semibold shadow-sm'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group rounded-xl overflow-hidden silver-card flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:border-white/30"
            >
              {/* Image Showcase Frame */}
              <div 
                className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-900 cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 filter contrast-[1.03]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Subtle scrim & action button overlay */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center p-4">
                  <span className="px-4 py-2 bg-white text-black text-xs font-bold uppercase tracking-wider rounded-sm shadow-md flex items-center gap-2">
                    <Eye className="w-3.5 h-3.5" />
                    <span>Ver Projeto Completo</span>
                  </span>
                </div>

                {/* Badge top-left */}
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/75 backdrop-blur-md border border-white/15 text-[11px] font-mono text-neutral-200">
                  {project.deliveryTime}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-1.5">
                    <span>{project.niche}</span>
                    <span aria-hidden="true">·</span>
                    <span>{project.year}</span>
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-neutral-200 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                {/* Result Proof Adjacency */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <div>
                    <div className="text-xs text-neutral-400">Resultado Principal</div>
                    <div className="text-base font-extrabold text-white tabular-nums">
                      {project.metric}
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedProject(project)}
                    className="text-xs font-semibold text-neutral-300 hover:text-white flex items-center gap-1 group/btn p-1"
                  >
                    <span>Detalhes</span>
                    <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Banner with Direct Call to Action */}
        <div className="mt-16 p-8 rounded-xl bg-gradient-to-r from-neutral-900 to-[#121217] border border-white/15 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-lg sm:text-xl font-bold text-white">
              Seu nicho é outro? Desenvolvemos para qualquer segmento de mercado.
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
              De comércios locais e prestadores de serviços a profissionais liberais, adaptamos o design para falar exatamente a língua do seu público.
            </p>
          </div>

          <a
            href={getWhatsAppUrl('Olá! Gostaria de saber como a Kairo Studio pode criar um site para o meu nicho específico.')}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 shadow-sm"
          >
            <span>Consultar Meu Nicho no WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>

      {/* Project Detail Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
