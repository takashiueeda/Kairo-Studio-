import React, { useState } from 'react';
import { STUDIO_CONFIG, getWhatsAppUrl } from '../data/portfolioData';
import { ContactFormData } from '../types';
import { ArrowUpRight, Mail, Phone, Instagram, Send, CheckCircle2, Clock, Zap } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    phone: '',
    company: '',
    projectType: 'Landing Page de Alta Conversão',
    urgency: 'Entrega no Mesmo Dia (24h)',
    message: ''
  });

  const [submittedByEmail, setSubmittedByEmail] = useState(false);

  const handleSubmitWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const msg = `*Nova Solicitação de Orçamento - Kairo Studio*\n\n` +
      `*Nome:* ${formData.name}\n` +
      `*Empresa / Nicho:* ${formData.company || 'Não informado'}\n` +
      `*WhatsApp:* ${formData.phone || 'Não informado'}\n` +
      `*E-mail:* ${formData.email || 'Não informado'}\n` +
      `*Tipo de Site:* ${formData.projectType}\n` +
      `*Urgência:* ${formData.urgency}\n` +
      `*Mensagem:* ${formData.message || 'Gostaria de um orçamento detalhado.'}`;

    window.open(getWhatsAppUrl(msg), '_blank');
  };

  const handleSubmitEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;

    setSubmittedByEmail(true);
    // Also prepare mailto fallback
    const subject = encodeURIComponent(`Solicitação de Orçamento: ${formData.projectType} - ${formData.name}`);
    const body = encodeURIComponent(
      `Nome: ${formData.name}\nEmpresa: ${formData.company}\nTelefone: ${formData.phone}\nE-mail: ${formData.email}\nTipo: ${formData.projectType}\nPrazo: ${formData.urgency}\n\nMensagem:\n${formData.message}`
    );
    window.location.href = `mailto:${STUDIO_CONFIG.email}?subject=${subject}&body=${body}`;
  };

  return (
    <section id="contato" className="py-20 md:py-28 border-b border-white/10 bg-[#09090b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
            <span>Iniciar Projeto</span>
            <span aria-hidden="true">·</span>
            <span>Atendimento Rápido e Direto</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance">
            Vamos construir o site que a sua empresa merece
          </h2>
          <p className="text-base text-neutral-400 mt-4 leading-relaxed">
            Preencha os campos abaixo para solicitar uma proposta personalizada ou fale conosco instantaneamente pelo WhatsApp ou e-mail.
          </p>
        </div>

        {/* 2-Column Split: Direct Contact Info & Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Column 1: Direct Channels & Commitment */}
          <div className="lg:col-span-5 space-y-8">
            
            <div className="p-8 rounded-xl silver-card space-y-6">
              <h3 className="text-xl font-bold text-white">
                Canais de Atendimento Direto
              </h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Você conversa diretamente com a Kairo Studio pelo WhatsApp ou e-mail, sem burocracia ou intermediários.
              </p>

              <div className="space-y-4 pt-2">
                {/* WhatsApp */}
                <a
                  href={getWhatsAppUrl('Olá! Gostaria de falar diretamente com a Kairo Studio pelo WhatsApp.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-4 p-4 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors group"
                >
                  <div className="p-2.5 rounded bg-white/10 text-white shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400 uppercase tracking-wider font-mono">
                      WhatsApp Oficial
                    </div>
                    <div className="text-sm sm:text-base font-bold text-white group-hover:text-neutral-200 mt-0.5">
                      {STUDIO_CONFIG.whatsappNumber}
                    </div>
                    <div className="text-xs text-neutral-400 mt-1 flex items-center gap-1">
                      <span>Atendimento rápido em todo o Brasil</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </div>
                  </div>
                </a>

                {/* Instagram */}
                <a
                  href={STUDIO_CONFIG.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-4 p-4 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors group"
                >
                  <div className="p-2.5 rounded bg-white/10 text-white shrink-0">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400 uppercase tracking-wider font-mono">
                      Instagram do Estúdio
                    </div>
                    <div className="text-sm sm:text-base font-bold text-white group-hover:text-neutral-200 mt-0.5">
                      {STUDIO_CONFIG.instagram}
                    </div>
                    <div className="text-xs text-neutral-400 mt-1 flex items-center gap-1">
                      <span>Acompanhe bastidores e novos lançamentos</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </div>
                  </div>
                </a>

                {/* Email */}
                <a
                  href={`mailto:${STUDIO_CONFIG.email}`}
                  className="flex items-start gap-4 p-4 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors group"
                >
                  <div className="p-2.5 rounded bg-white/10 text-white shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-400 uppercase tracking-wider font-mono">
                      E-mail Profissional
                    </div>
                    <div className="text-sm sm:text-base font-bold text-white group-hover:text-neutral-200 mt-0.5">
                      {STUDIO_CONFIG.email}
                    </div>
                    <div className="text-xs text-neutral-400 mt-1">
                      Envio de briefings, arquivos e propostas formais
                    </div>
                  </div>
                </a>
              </div>
            </div>

            {/* Fast-track assurance badge */}
            <div className="p-6 rounded-xl bg-white/[0.02] border border-white/10 flex items-start gap-4">
              <Zap className="w-5 h-5 text-white shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-bold text-white">
                  Garantia de Entrega no Mesmo Dia
                </div>
                <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                  Para demandas urgentes, confirmamos o início no mesmo dia útil e priorizamos seu site para ir ao ar dentro de 24 horas.
                </p>
              </div>
            </div>

          </div>

          {/* Column 2: Lead Capture Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-xl silver-card border border-white/20">
              
              <h3 className="text-2xl font-bold text-white mb-2">
                Solicitar Orçamento Personalizado
              </h3>
              <p className="text-xs text-neutral-400 mb-8">
                Leva menos de 1 minuto. Resposta direta com estimativa de valor e prazo.
              </p>

              {submittedByEmail ? (
                <div className="p-8 text-center space-y-4 bg-white/5 border border-white/20 rounded-lg">
                  <CheckCircle2 className="w-12 h-12 text-white mx-auto" />
                  <h4 className="text-xl font-bold text-white">Solicitação Encaminhada!</h4>
                  <p className="text-sm text-neutral-300">
                    Seu cliente de e-mail foi aberto com as informações do seu projeto. Você também pode acelerar o processo enviando agora pelo WhatsApp.
                  </p>
                  <a
                    href={getWhatsAppUrl(`Olá! Acabei de enviar um formulário de orçamento para meu site e gostaria de agilizar o contato.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 text-xs font-bold uppercase tracking-wider text-black bg-white rounded-sm mt-4 hover:bg-neutral-200 transition-colors"
                  >
                    <span>Falar no WhatsApp Agora</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              ) : (
                <form className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                        Seu Nome *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: Rafael Silva"
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                        Empresa ou Nicho
                      </label>
                      <input
                        type="text"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        placeholder="Ex: Clínica Médica / Advocacia / Loja"
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                        WhatsApp com DDD *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="(98) 98869-7699"
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                        Seu E-mail
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="seuemail@empresa.com"
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                        Tipo de Site
                      </label>
                      <select
                        value={formData.projectType}
                        onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg bg-[#141419] border border-white/10 text-white focus:outline-none focus:border-white transition-colors text-sm"
                      >
                        <option value="Site Simples (R$ 150)">Site Simples (R$ 150)</option>
                        <option value="Site Essencial (R$ 300)">Site Essencial (R$ 300)</option>
                        <option value="Site Premium (R$ 600)">Site Premium (R$ 600)</option>
                        <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão</option>
                        <option value="Catálogo Digital / Vitrine">Catálogo Digital / Vitrine</option>
                        <option value="Outro Formato / Projeto Específico">Outro Formato / Projeto Específico</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                        Prazo Desejado
                      </label>
                      <select
                        value={formData.urgency}
                        onChange={(e) => setFormData({ ...formData, urgency: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg bg-[#141419] border border-white/10 text-white focus:outline-none focus:border-white transition-colors text-sm"
                      >
                        <option value="Fast-Track - No Mesmo Dia (+15%)">Fast-Track - No Mesmo Dia (+15%)</option>
                        <option value="Ágil - Em até 48 horas (+10%)">Ágil - Em até 48 horas (+10%)</option>
                        <option value="Padrão - Em 3 a 5 dias úteis">Padrão - Em 3 a 5 dias úteis</option>
                        <option value="Apenas pesquisando valores">Apenas pesquisando valores</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                      Detalhes ou Ideias para o Site
                    </label>
                    <textarea
                      rows={3}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Conte um pouco sobre o que sua empresa vende e o que você gostaria de ter no site..."
                      className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder-neutral-500 focus:outline-none focus:border-white transition-colors text-sm"
                    />
                  </div>

                  {/* Dual Action Buttons: Primary WhatsApp + Alternative Email */}
                  <div className="pt-4 flex flex-col sm:flex-row gap-3">
                    <button
                      type="button"
                      onClick={handleSubmitWhatsApp}
                      className="flex-1 py-4 px-6 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-all duration-150 flex items-center justify-center gap-2 shadow-md cursor-pointer"
                    >
                      <Phone className="w-4 h-4" />
                      <span>Solicitar Orçamento no WhatsApp</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={handleSubmitEmail}
                      className="py-4 px-6 text-xs font-medium uppercase tracking-wider text-neutral-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Mail className="w-4 h-4" />
                      <span>Enviar por E-mail</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-neutral-500 text-center pt-2">
                    Ao enviar, você fala diretamente com o desenvolvedor responsável pela Kairo Studio.
                  </p>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
