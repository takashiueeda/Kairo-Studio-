import React, { useState } from 'react';
import { getWhatsAppUrl } from '../data/portfolioData';
import { ArrowUpRight, Check, Zap, Clock, ShieldCheck, Sparkles } from 'lucide-react';

interface SitePlan {
  id: 'simples' | 'essencial' | 'premium';
  name: string;
  basePrice: number;
  badge: string;
  desc: string;
  highlights: string[];
}

const SITE_PLANS: SitePlan[] = [
  {
    id: 'simples',
    name: 'Site Simples',
    basePrice: 150,
    badge: 'Mais Acessível',
    desc: 'Página única ou landing page essencial, limpa, objetiva e com foco em conversão direta no WhatsApp.',
    highlights: [
      'Página única focada em conversão',
      'Botões diretos para WhatsApp',
      'Layout 100% responsivo para celular',
      'Carregamento rápido e leve'
    ]
  },
  {
    id: 'essencial',
    name: 'Site Essencial',
    basePrice: 300,
    badge: 'Mais Escolhido',
    desc: 'Site completo com múltiplas seções institucionais (Apresentação, Serviços, Sobre e Contato) para gerar autoridade.',
    highlights: [
      'Estrutura completa em seções',
      'Formulário e canais integrados',
      'Design preto, prata e branco moderno',
      'Indexação básica no Google'
    ]
  },
  {
    id: 'premium',
    name: 'Site Premium',
    basePrice: 600,
    badge: 'Máximo Impacto',
    desc: 'Presença digital de alta performance, arquitetura personalizada, catálogo/portfólio rico e acabamento sofisticado.',
    highlights: [
      'Identidade visual de alto padrão',
      'Vitrine/Catálogo ou portfólio ampliado',
      'Animações suaves e micro-interações',
      'Otimização avançada de performance'
    ]
  }
];

type UrgencyType = 'padrao' | 'agil' | 'fast-track';

interface UrgencyOption {
  id: UrgencyType;
  title: string;
  timeframe: string;
  percentageExtra: number;
  badge: string;
  note: string;
  icon?: typeof Zap;
}

const URGENCY_OPTIONS: UrgencyOption[] = [
  {
    id: 'padrao',
    title: 'Padrão',
    timeframe: '3 a 5 dias úteis',
    percentageExtra: 0,
    badge: 'Sem Acréscimo',
    note: 'Prazo tranquilo para quem está organizando os materiais do projeto.'
  },
  {
    id: 'agil',
    title: 'Ágil',
    timeframe: 'Em até 48 horas',
    percentageExtra: 10,
    badge: '+10% no valor',
    note: 'Produção rápida com prioridade acelerada para seu negócio ir ao ar.'
  },
  {
    id: 'fast-track',
    title: 'Fast-Track',
    timeframe: 'No Mesmo Dia (até 24h)',
    percentageExtra: 15,
    badge: '+15% no valor',
    note: 'Prioridade máxima na fila para entregar seu site em até 24 horas.',
    icon: Zap
  }
];

export const BudgetSimulator: React.FC = () => {
  const [selectedPlanId, setSelectedPlanId] = useState<'simples' | 'essencial' | 'premium'>('essencial');
  const [selectedUrgencyId, setSelectedUrgencyId] = useState<UrgencyType>('fast-track');
  const [includedFeatures, setIncludedFeatures] = useState<string[]>([
    'whatsapp-direct',
    'mobile-first',
    'copywriting'
  ]);

  const toggleFeature = (featId: string) => {
    if (includedFeatures.includes(featId)) {
      setIncludedFeatures(includedFeatures.filter((id) => id !== featId));
    } else {
      setIncludedFeatures([...includedFeatures, featId]);
    }
  };

  const currentPlan = SITE_PLANS.find((p) => p.id === selectedPlanId) || SITE_PLANS[1];
  const currentUrgency = URGENCY_OPTIONS.find((u) => u.id === selectedUrgencyId) || URGENCY_OPTIONS[2];

  // Price calculations
  const basePrice = currentPlan.basePrice;
  const extraPercentage = currentUrgency.percentageExtra;
  const urgencyAddition = (basePrice * extraPercentage) / 100;
  const totalPrice = basePrice + urgencyAddition;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 2
    }).format(val);
  };

  const featureOptions = [
    { id: 'whatsapp-direct', name: 'Botões de Contato com Mensagem Personalizada no WhatsApp' },
    { id: 'mobile-first', name: 'Layout Mobile-First Otimizado para Smartphones' },
    { id: 'copywriting', name: 'Textos Estruturados com Foco em Vendas e Faturamento' },
    { id: 'seo-tags', name: 'Configurações de SEO e Meta Tags para o Google' }
  ];

  // Generate WhatsApp message with exact quote details
  const generateWhatsAppMessage = () => {
    const lines = [
      `*Simulação de Orçamento - Kairo Studio*`,
      ``,
      `*Plano Escolhido:* ${currentPlan.name}`,
      `*Valor Base:* ${formatCurrency(basePrice)}`,
      `*Prazo de Entrega:* ${currentUrgency.title} (${currentUrgency.timeframe})`,
      extraPercentage > 0 ? `*Acréscimo de Prazo:* +${extraPercentage}% (+${formatCurrency(urgencyAddition)})` : `*Acréscimo de Prazo:* Sem acréscimo`,
      `*Investimento Total:* ${formatCurrency(totalPrice)}`,
      ``,
      `*Recursos Selecionados:*`,
      ...featureOptions
        .filter((f) => includedFeatures.includes(f.id))
        .map((f) => `• ${f.name}`),
      ``,
      `Gostaria de fechar este pacote e verificar o início do projeto!`
    ];

    return lines.join('\n');
  };

  return (
    <section id="simulador" className="py-20 md:py-28 border-b border-white/10 bg-[#09090b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
            <span>Simulador Interativo de Preços</span>
            <span aria-hidden="true">·</span>
            <span>Valores Claros & Sem Surpresas</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance">
            Calcule o valor do seu site com total transparência
          </h2>
          <p className="text-base text-neutral-400 mt-4 leading-relaxed">
            Selecione o modelo ideal para o seu momento e escolha a velocidade de entrega desejada.
          </p>
        </div>

        {/* Simulator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Column */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* Step 1: Seleção do Modelo de Site */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-sm font-semibold uppercase tracking-wider text-neutral-300">
                  1. Escolha o Modelo do Site
                </label>
                <span className="text-xs text-neutral-400">Preços base a partir de R$ 150</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {SITE_PLANS.map((plan) => {
                  const isSelected = selectedPlanId === plan.id;
                  return (
                    <button
                      key={plan.id}
                      onClick={() => setSelectedPlanId(plan.id)}
                      className={`p-4 rounded-xl text-left border transition-all cursor-pointer relative flex flex-col justify-between ${
                        isSelected
                          ? 'bg-white/10 border-white text-white shadow-lg ring-1 ring-white/30'
                          : 'bg-white/[0.02] border-white/10 text-neutral-300 hover:border-white/20 hover:bg-white/[0.04]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-400">
                            {plan.badge}
                          </span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <div className="font-bold text-base text-white">
                          {plan.name}
                        </div>
                        <div className="text-xs text-neutral-400 mt-1 line-clamp-2 leading-relaxed">
                          {plan.desc}
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-white/10">
                        <span className="text-[11px] text-neutral-400 block">Investimento base</span>
                        <span className="text-lg font-extrabold text-white tabular-nums">
                          {formatCurrency(plan.basePrice)}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Escolha do Prazo de Entrega */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-sm font-semibold uppercase tracking-wider text-neutral-300">
                  2. Prazo de Entrega
                </label>
                <span className="text-xs text-neutral-400">Ágil (+10%) · Fast-Track (+15%)</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {URGENCY_OPTIONS.map((urg) => {
                  const isSelected = selectedUrgencyId === urg.id;
                  const Icon = urg.icon;
                  return (
                    <button
                      key={urg.id}
                      onClick={() => setSelectedUrgencyId(urg.id)}
                      className={`p-4 rounded-xl text-left border transition-all cursor-pointer relative flex flex-col justify-between ${
                        isSelected
                          ? 'bg-white/10 border-white text-white shadow-lg ring-1 ring-white/30'
                          : 'bg-white/[0.02] border-white/10 text-neutral-400 hover:border-white/20 hover:bg-white/[0.04]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1.5">
                          <span className="text-xs font-bold uppercase tracking-wider text-white">
                            {urg.title}
                          </span>
                          {Icon && <Icon className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <div className="text-xs font-medium text-neutral-200">
                          {urg.timeframe}
                        </div>
                      </div>

                      <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between">
                        <span className="text-[11px] font-mono text-neutral-300">
                          {urg.badge}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              <p className="text-xs text-neutral-400 mt-2">
                * {currentUrgency.note}
              </p>
            </div>

            {/* Step 3: Recursos e Benefícios */}
            <div>
              <label className="block text-sm font-semibold uppercase tracking-wider text-neutral-300 mb-3">
                3. Recursos Incluídos na Estrutura
              </label>

              <div className="space-y-2.5">
                {featureOptions.map((feat) => {
                  const isChecked = includedFeatures.includes(feat.id);
                  return (
                    <button
                      key={feat.id}
                      onClick={() => toggleFeature(feat.id)}
                      className={`w-full p-3.5 rounded-lg text-left border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isChecked
                          ? 'bg-white/[0.06] border-white/30 text-white'
                          : 'bg-white/[0.01] border-white/10 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <span className="text-xs sm:text-sm font-medium">
                        {feat.name}
                      </span>
                      <div className={`w-5 h-5 rounded border flex items-center justify-center shrink-0 ${
                        isChecked ? 'bg-white border-white text-black' : 'border-neutral-600'
                      }`}>
                        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Proposal Summary Column */}
          <div className="lg:col-span-5">
            <div className="p-8 rounded-xl silver-card border border-white/20 sticky top-28 space-y-6">
              
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Resumo da Proposta
                </div>
                <div className="px-2 py-0.5 rounded bg-white/10 text-[11px] font-mono text-white">
                  Kairo Studio
                </div>
              </div>

              {/* Plan Details */}
              <div>
                <span className="text-xs text-neutral-400">Modelo Selecionado:</span>
                <div className="text-2xl font-bold text-white mt-0.5">
                  {currentPlan.name}
                </div>
                <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                  {currentPlan.desc}
                </p>
              </div>

              {/* Price Breakdown */}
              <div className="space-y-2.5 text-xs text-neutral-300 py-4 border-y border-white/10">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Valor Base do Site:</span>
                  <span className="text-white font-mono font-medium">{formatCurrency(basePrice)}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">
                    Prazo ({currentUrgency.title}):
                  </span>
                  <span className="text-white font-mono font-medium">
                    {extraPercentage > 0 ? `+${extraPercentage}% (+${formatCurrency(urgencyAddition)})` : 'Sem taxa extra'}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-neutral-400">Tempo de Produção:</span>
                  <span className="text-white font-semibold flex items-center gap-1">
                    {selectedUrgencyId === 'fast-track' && <Zap className="w-3 h-3 text-white" />}
                    {currentUrgency.timeframe}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  <span className="text-sm font-semibold text-white">Valor Final:</span>
                  <span className="text-2xl font-extrabold text-white font-mono tabular-nums">
                    {formatCurrency(totalPrice)}
                  </span>
                </div>
              </div>

              {/* Deliverables checklist preview */}
              <div className="space-y-2 pt-1">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 block">
                  Destaques inclusos:
                </span>
                <ul className="space-y-1.5">
                  {currentPlan.highlights.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs text-neutral-300">
                      <Check className="w-3.5 h-3.5 text-white shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div className="space-y-3 pt-2">
                <a
                  href={getWhatsAppUrl(generateWhatsAppMessage())}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-4 px-6 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-all text-center flex items-center justify-center gap-2 shadow-lg"
                >
                  <span>Pedir Este Site no WhatsApp ({formatCurrency(totalPrice)})</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>

                <div className="text-[11px] text-neutral-400 text-center leading-normal">
                  Sem burocracia · Pagamento facilitado · Atendimento direto
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
