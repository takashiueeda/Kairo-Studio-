import React from 'react';
import { Project } from '../types';
import { getWhatsAppUrl } from '../data/portfolioData';
import { X, ArrowUpRight, Check, Clock, TrendingUp } from 'lucide-react';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#0d0d12] border border-white/20 rounded-xl p-6 sm:p-8 shadow-2xl text-white"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-colors"
          aria-label="Fechar detalhes do projeto"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-6 pr-10">
          <div className="flex items-center gap-2 text-xs font-mono uppercase text-neutral-400 mb-2">
            <span>{project.niche}</span>
            <span aria-hidden="true">·</span>
            <span>{project.deliveryTime}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            {project.title}
          </h2>
          <p className="text-sm text-neutral-300 mt-1">
            {project.tagline}
          </p>
        </div>

        {/* Featured Image */}
        <div className="rounded-lg overflow-hidden border border-white/10 mb-8 bg-black">
          <div className="relative aspect-[16/9] w-full">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover object-center"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="md:col-span-2 space-y-4">
            <h3 className="text-base font-bold text-white">
              Sobre a Solução Desenvolvida
            </h3>
            <p className="text-sm text-neutral-300 leading-relaxed">
              {project.description}
            </p>

            <div className="pt-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-3">
                Recursos Implementados:
              </h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {project.features.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-xs text-neutral-200">
                    <Check className="w-4 h-4 text-white shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="p-5 rounded-lg bg-white/5 border border-white/10 flex flex-col justify-between space-y-4">
            <div>
              <div className="text-xs text-neutral-400 uppercase tracking-wider font-mono">
                Resultado Mensurável
              </div>
              <div className="text-3xl font-extrabold text-white mt-1 tabular-nums">
                {project.metric}
              </div>
              <div className="text-xs text-neutral-300 mt-1">
                {project.metricLabel}
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-2 text-xs text-neutral-400">
              <div className="flex items-center justify-between">
                <span>Cliente:</span>
                <span className="text-white font-medium">{project.client}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Prazo de Criação:</span>
                <span className="text-white font-medium">{project.deliveryTime}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Ano de Lançamento:</span>
                <span className="text-white font-medium">{project.year}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer / Primary CTA */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          <div className="text-xs text-neutral-400">
            Deseja uma página com esta qualidade visual para a sua empresa?
          </div>

          <a
            href={getWhatsAppUrl(`Olá! Gostei muito do projeto ${project.title} da Kairo Studio. Gostaria de solicitar um orçamento para um site similar.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors text-center flex items-center justify-center gap-2 shadow-sm"
          >
            <span>Pedir Site com Este Padrão no WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </div>
  );
};
