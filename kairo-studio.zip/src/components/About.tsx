import React from 'react';
import { STUDIO_CONFIG, getWhatsAppUrl } from '../data/portfolioData';
import { ArrowUpRight, CheckCircle2, ShieldCheck, Zap, Sparkles } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-20 md:py-28 border-b border-white/10 bg-[#09090b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
            <span>Conheça a Kairo Studio</span>
            <span aria-hidden="true">·</span>
            <span>Trajetória & Propósito</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance">
            Construindo soluções digitais que geram valor real para o seu negócio
          </h2>
          <p className="text-base text-neutral-400 mt-4 leading-relaxed">
            Unimos design contemporâneo, velocidade de carregamento e foco comercial para empresas que buscam credibilidade inabalável na internet.
          </p>
        </div>

        {/* Narrative & Pillars Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Main Story Narrative */}
          <div className="lg:col-span-7 space-y-6 text-neutral-300 text-base sm:text-lg leading-relaxed">
            <div className="p-6 sm:p-8 rounded-xl bg-white/[0.04] border border-white/10 text-white font-medium text-lg sm:text-xl leading-relaxed shadow-sm">
              "{STUDIO_CONFIG.aboutStory.lead}"
            </div>

            {STUDIO_CONFIG.aboutStory.paragraphs.map((p, idx) => (
              <p key={idx} className="text-neutral-300 leading-relaxed">
                {p}
              </p>
            ))}

            <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href={getWhatsAppUrl('Olá! Li a apresentação da Kairo Studio e gostaria de conversar sobre um projeto de site.')}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors text-center flex items-center justify-center gap-2 shadow-sm"
              >
                <span>Falar com a Kairo Studio</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>

              <a
                href="#servicos"
                className="px-6 py-3.5 text-xs font-semibold uppercase tracking-wider text-neutral-300 hover:text-white border border-white/10 hover:border-white/30 rounded-sm transition-colors text-center"
              >
                Ver Serviços Disponíveis
              </a>
            </div>
          </div>

          {/* Pillars & Studio Commitments Column */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="p-8 rounded-xl silver-card space-y-6">
              <div className="text-xs uppercase tracking-wider text-neutral-400 font-semibold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-white" />
                <span>Nossos Pilares de Trabalho</span>
              </div>

              <ul className="space-y-4 text-sm text-neutral-300">
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-white shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Sem burocracia ou intermediários</strong>
                    <span className="text-xs text-neutral-400">Atendimento direto pelo WhatsApp com quem desenvolve seu site.</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-white shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Agilidade máxima</strong>
                    <span className="text-xs text-neutral-400">Opção de entrega expressa no mesmo dia (Fast-Track 24h).</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-white shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Excelente custo-benefício</strong>
                    <span className="text-xs text-neutral-400">Preços transparentes e justos pensados para empresas reais.</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 className="w-4 h-4 text-white shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block font-semibold">Foco em faturamento</strong>
                    <span className="text-xs text-neutral-400">Páginas desenhadas para transformar visitantes em contatos comerciais.</span>
                  </div>
                </li>
              </ul>
            </div>

            {/* Quick metrics strip */}
            <div className="grid grid-cols-3 gap-3 p-6 rounded-xl bg-white/[0.02] border border-white/10">
              <div>
                <div className="text-2xl font-extrabold text-white tabular-nums">24h</div>
                <div className="text-[11px] text-neutral-400 mt-1 leading-tight">Entrega expressa</div>
              </div>
              <div>
                <div className="text-2xl font-extrabold text-white tabular-nums">100%</div>
                <div className="text-[11px] text-neutral-400 mt-1 leading-tight">Dedicação ao cliente</div>
              </div>
              <div>
                <div className="text-2xl font-extrabold text-white tabular-nums">Brasil</div>
                <div className="text-[11px] text-neutral-400 mt-1 leading-tight">Atendimento online</div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
