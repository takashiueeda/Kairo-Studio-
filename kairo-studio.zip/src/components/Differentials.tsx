import React from 'react';
import { COMPARISON_POINTS, getWhatsAppUrl } from '../data/portfolioData';
import { Check, X, Zap, Shield, TrendingUp, Sparkles, ArrowUpRight } from 'lucide-react';

export const Differentials: React.FC = () => {
  return (
    <section id="diferenciais" className="py-20 md:py-28 border-b border-white/10 bg-[#0c0c10]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
            <span>Diferenciais Competitivos</span>
            <span aria-hidden="true">·</span>
            <span>Por que escolher a Kairo Studio</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white text-balance">
            Velocidade expressa, custo justo e foco no faturamento da sua empresa
          </h2>
          <p className="text-base text-neutral-400 mt-4 leading-relaxed">
            Eliminamos os atrasos, os orçamentos inflados e a burocracia que travam as empresas brasileiras no digital.
          </p>
        </div>

        {/* 3 Core Differentials Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          
          <div className="p-8 rounded-xl silver-card flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">
                Entrega no Mesmo Dia
              </h3>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Enquanto o mercado tradicional pede 30 a 60 dias para entregar um site básico, nós colocamos seu projeto no ar em até 24 horas através de uma metodologia enxuta e focada.
              </p>
            </div>
            <div className="pt-4 border-t border-white/10 text-xs font-mono text-neutral-400">
              Prazo real · Sem desculpas
            </div>
          </div>

          <div className="p-8 rounded-xl silver-card flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">
                Excelente Custo-Benefício
              </h3>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Você não paga por custos fixos de agências inchadas. Nosso modelo é direto, transparente e oferece uma estética de luxo acessível para quem quer retorno financeiro rápido.
              </p>
            </div>
            <div className="pt-4 border-t border-white/10 text-xs font-mono text-neutral-400">
              Investimento inteligente
            </div>
          </div>

          <div className="p-8 rounded-xl silver-card flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center text-white">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">
                Foco em Faturamento
              </h3>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Um site bonito que não vende é inútil. Construímos sua presença digital focada em passar credibilidade instantânea e levar os visitantes qualificados direto para o seu WhatsApp.
              </p>
            </div>
            <div className="pt-4 border-t border-white/10 text-xs font-mono text-neutral-400">
              Conversão comprovada
            </div>
          </div>

        </div>

        {/* Detailed Comparison Table */}
        <div className="rounded-xl overflow-hidden border border-white/15 bg-[#09090b]">
          <div className="p-6 sm:p-8 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-white">
                Comparativo Transparente
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                Veja a diferença prática entre o modelo tradicional e a proposta da Kairo Studio
              </p>
            </div>
            <div className="text-xs font-medium text-neutral-400">
              Sem letras miúdas
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-white/[0.02] text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                  <th className="py-4 px-6">Critério</th>
                  <th className="py-4 px-6 text-neutral-400">Agências Tradicionais</th>
                  <th className="py-4 px-6 text-white font-bold bg-white/5">Kairo Studio (Nossa Abordagem)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-sm">
                {COMPARISON_POINTS.map((item, idx) => (
                  <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-4 px-6 font-semibold text-white whitespace-nowrap">
                      {item.criteria}
                    </td>
                    <td className="py-4 px-6 text-neutral-400 flex items-center gap-2">
                      <X className="w-4 h-4 text-neutral-500 shrink-0" />
                      <span>{item.traditionalAgency}</span>
                    </td>
                    <td className="py-4 px-6 text-white font-medium bg-white/5">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-white shrink-0" />
                        <span>{item.kairoStudio}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-6 bg-white/[0.02] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-neutral-400 text-center sm:text-left">
              Pronto para colocar sua empresa em outro patamar digital?
            </span>
            <a
              href={getWhatsAppUrl('Olá! Vi os diferenciais da Kairo Studio e quero aproveitar a entrega expressa e o excelente custo-benefício.')}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors flex items-center gap-2"
            >
              <span>Solicitar Orçamento no WhatsApp</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
