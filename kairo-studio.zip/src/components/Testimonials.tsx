import React from 'react';
import { TESTIMONIALS, getWhatsAppUrl } from '../data/portfolioData';
import { Quote, ArrowUpRight, CheckCircle2, TrendingUp, Clock } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section id="depoimentos" className="py-20 md:py-28 border-b border-white/10 bg-[#0c0c10]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
              <span>Depoimentos & Casos Reais</span>
              <span aria-hidden="true">·</span>
              <span>Resultados que Comprovam</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white max-w-2xl text-balance">
              Quem confiou na Kairo Studio viu o resultado no faturamento
            </h2>
          </div>

          <div className="text-sm text-neutral-400 max-w-sm">
            Empresários e profissionais que transformaram sua presença online com agilidade extrema, design de alto padrão e investimento justo.
          </div>
        </div>

        {/* Testimonials 2x2 Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="p-8 rounded-xl silver-card flex flex-col justify-between space-y-6 relative transition-all duration-300 hover:border-white/30"
            >
              <div className="space-y-4">
                {/* Header of the card: Niche & Delivery speed unboxed */}
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-400 border-b border-white/10 pb-3">
                  <span className="font-mono text-neutral-300">{t.niche}</span>
                  <span className="text-neutral-400 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{t.speed}</span>
                  </span>
                </div>

                <Quote className="w-8 h-8 text-neutral-600" />
                <p className="text-sm sm:text-base text-neutral-200 leading-relaxed italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Bottom Outcome & Author attribution */}
              <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="font-bold text-white text-base">
                    {t.name}
                  </div>
                  <div className="text-xs text-neutral-400">
                    {t.role} · {t.company}
                  </div>
                  <div className="text-[11px] text-neutral-500 mt-0.5">
                    {t.city}
                  </div>
                </div>

                {/* Quantified Outcome */}
                <div className="sm:text-right shrink-0">
                  <div className="text-xs text-neutral-400">Resultado Alcançado</div>
                  <div className="text-base font-extrabold text-white tabular-nums">
                    {t.metric}
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    {t.metricContext}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner Adjacency */}
        <div className="mt-16 p-8 rounded-xl bg-gradient-to-r from-neutral-900 to-[#121217] border border-white/15 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-lg sm:text-xl font-bold text-white">
              Quer ter o próximo site de sucesso da sua área?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
              Colocamos seu site no ar no mesmo dia ou em até 48 horas com padrão visual extraordinário e preços a partir de R$ 150.
            </p>
          </div>

          <a
            href={getWhatsAppUrl('Olá! Vi os depoimentos dos clientes da Kairo Studio e gostaria de iniciar meu site agora.')}
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-2 shadow-sm"
          >
            <span>Quero Meu Site com a Kairo Studio</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
};
