import React, { useState } from 'react';
import { getWhatsAppUrl, STUDIO_CONFIG } from '../data/portfolioData';
import { MessageCircle, X, ArrowUpRight, Zap } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <aside aria-label="Atendimento via WhatsApp" className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      
      {/* Popover Card */}
      {isOpen && (
        <div className="mb-3 w-80 p-5 rounded-xl bg-[#0e0e14] border border-white/20 shadow-2xl text-white animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-start justify-between gap-3 mb-3 pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center font-bold text-xs">
                KS
              </div>
              <div>
                <div className="text-xs font-bold text-white">Kairo Studio</div>
                <div className="text-[11px] text-neutral-400">Atendimento WhatsApp</div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-neutral-400 hover:text-white p-1"
              aria-label="Fechar janela do WhatsApp"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed mb-4">
            Olá! Precisa de um site extraordinário para aumentar suas vendas com <strong>entrega expressa no mesmo dia</strong>?
          </p>

          <a
            href={getWhatsAppUrl('Olá! Vi o site da Kairo Studio e gostaria de conversar sobre um projeto.')}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 px-4 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Iniciar Conversa</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      )}

      {/* Floating Trigger Button */}
      <div className="flex items-center gap-2">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="hidden sm:flex items-center gap-2 py-2 px-3 rounded-full bg-[#121218]/90 backdrop-blur-md border border-white/15 text-xs text-neutral-300 hover:text-white hover:border-white/30 transition-all shadow-lg cursor-pointer"
          >
            <span className="w-2 h-2 rounded-full bg-white"></span>
            <span>Orçamento no WhatsApp</span>
          </button>
        )}

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-13 h-13 rounded-full bg-white text-black hover:bg-neutral-200 transition-all duration-200 flex items-center justify-center shadow-xl hover:scale-105 cursor-pointer relative"
          aria-label="Abrir atendimento no WhatsApp"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="sr-only">WhatsApp da Kairo Studio</span>
        </button>
      </div>

    </aside>
  );
};
