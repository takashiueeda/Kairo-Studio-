import React from 'react';
import { getWhatsAppUrl, STUDIO_CONFIG } from '../data/portfolioData';
import { ArrowUpRight, Zap, ShieldCheck, TrendingUp, Sparkles } from 'lucide-react';
import heroWorkspaceImg from '../assets/images/hero_minimal_workspace_1794399895151.jpg';

export const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-32 border-b border-white/10">
      {/* Background glow effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-b from-white/5 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Unboxed Metadata & Category Lead */}
        <div className="flex flex-wrap items-center gap-2 text-xs md:text-sm font-medium text-neutral-400 mb-6">
          <span className="text-white font-semibold tracking-wider uppercase">Kairo Studio</span>
          <span aria-hidden="true" className="text-neutral-600">·</span>
          <span>Desenvolvimento Web & Alta Conversão</span>
          <span aria-hidden="true" className="text-neutral-600">·</span>
          <span>Brasil</span>
        </div>

        {/* Main Headline & Tagline */}
        <div className="max-w-4xl">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.08] mb-6 text-balance">
            <span className="block silver-gradient-text">
              {STUDIO_CONFIG.tagline}
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-neutral-300 leading-relaxed max-w-3xl mb-8 font-normal">
            Criamos sites modernos, ultra-rápidos e focados no crescimento do seu faturamento. 
            Soluções digitais com visual de alto padrão, <strong className="text-white font-semibold">entrega no mesmo dia</strong> e o 
            melhor <strong className="text-white font-semibold">custo-benefício</strong> para sua empresa dominar o mercado online.
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-14">
            <a
              href={getWhatsAppUrl('Olá! Quero transformar a presença digital da minha empresa. Gostaria de solicitar um orçamento no WhatsApp.')}
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 text-sm font-bold tracking-wider uppercase text-black bg-white hover:bg-neutral-200 rounded-sm transition-all duration-150 text-center flex items-center justify-center gap-2 shadow-lg hover:shadow-white/10"
            >
              <span>Solicitar Orçamento no WhatsApp</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>

            <a
              href="#portfolio"
              className="px-7 py-4 text-sm font-medium text-neutral-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-sm transition-all text-center flex items-center justify-center gap-2"
            >
              <span>Ver Projetos Recentes</span>
            </a>
            
            <a
              href="#simulador"
              className="px-6 py-4 text-sm font-medium text-neutral-300 hover:text-white border border-transparent hover:border-white/20 rounded-sm transition-all text-center flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-neutral-400" />
              <span>Simular Investimento</span>
            </a>
          </div>

          {/* 3 Pillars / Adjacency metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 border-t border-white/10">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded bg-white/5 border border-white/10 text-white shrink-0 mt-0.5">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-white">Entrega no Mesmo Dia</h2>
                <p className="text-xs text-neutral-400 mt-1 leading-normal">
                  Metodologia ágil para colocar sua empresa no ar em até 24 horas sem semanas de espera.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2 rounded bg-white/5 border border-white/10 text-white shrink-0 mt-0.5">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-white">Excelente Custo-Benefício</h2>
                <p className="text-xs text-neutral-400 mt-1 leading-normal">
                  Padrão estético de grande agência acessível para quem quer retorno financeiro imediato.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2 rounded bg-white/5 border border-white/10 text-white shrink-0 mt-0.5">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-white">Foco em Faturamento</h2>
                <p className="text-xs text-neutral-400 mt-1 leading-normal">
                  Estruturado para atrair visitantes qualificados e gerar chamados no seu WhatsApp comercial.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Studio Showcase Visual Frame */}
        <div className="mt-14 relative rounded-lg overflow-hidden border border-white/15 bg-neutral-950 shadow-2xl">
          <div className="relative aspect-[16/9] w-full max-h-[520px] overflow-hidden">
            <img
              src={heroWorkspaceImg}
              alt="Kairo Studio workspace minimalista e moderno"
              className="w-full h-full object-cover object-center filter contrast-[1.05]"
              referrerPolicy="no-referrer"
            />
            {/* Contrast Scrim */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-transparent to-transparent opacity-80" />
            
            {/* Visual caption */}
            <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-neutral-300 backdrop-blur-md bg-black/60 p-4 rounded border border-white/10">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-white shrink-0"></span>
                <span className="font-medium text-white">Ambiente de Criação & Engenharia Digital</span>
                <span aria-hidden="true" className="text-neutral-500">·</span>
                <span>Projetos com acabamento impecável em Preto & Prata</span>
              </div>
              <div className="text-neutral-400">
                Atendimento direto em todo o Brasil
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
