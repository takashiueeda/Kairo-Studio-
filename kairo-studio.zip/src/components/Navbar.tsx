import React, { useState } from 'react';
import { getWhatsAppUrl } from '../data/portfolioData';
import { Menu, X, ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  onOpenBudgetModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBudgetModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-[#09090b]/85 border-b border-white/10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#" 
          className="text-lg md:text-xl font-bold tracking-tight text-white hover:text-neutral-200 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 bg-white rotate-45 shrink-0 inline-block"></span>
          <span>KAIRO STUDIO</span>
        </a>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-300">
          <button 
            onClick={() => handleNavClick('#sobre')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Sobre
          </button>
          <button 
            onClick={() => handleNavClick('#servicos')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Serviços
          </button>
          <button 
            onClick={() => handleNavClick('#portfolio')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Portfólio
          </button>
          <button 
            onClick={() => handleNavClick('#diferenciais')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Diferenciais
          </button>
          <button 
            onClick={() => handleNavClick('#depoimentos')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Depoimentos
          </button>
          <button 
            onClick={() => handleNavClick('#simulador')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0 text-neutral-200"
          >
            Simulador
          </button>
          <button 
            onClick={() => handleNavClick('#contato')} 
            className="hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            Contato
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <a
            href={getWhatsAppUrl('Olá! Gostaria de solicitar um orçamento para criar meu site com a Kairo Studio.')}
            target="_blank"
            rel="noopener noreferrer"
            className="group px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-all duration-150 whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
          >
            <span>Solicitar Orçamento</span>
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>

        {/* Mobile menu toggle */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-neutral-400 hover:text-white transition-colors focus:outline-none"
            aria-label="Abrir menu de navegação"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-white/10 bg-[#09090b] px-6 py-6 space-y-4">
          <div className="flex flex-col space-y-3 text-base font-medium text-neutral-300">
            <button 
              onClick={() => handleNavClick('#sobre')} 
              className="text-left py-2 hover:text-white transition-colors border-b border-white/5"
            >
              Sobre
            </button>
            <button 
              onClick={() => handleNavClick('#servicos')} 
              className="text-left py-2 hover:text-white transition-colors border-b border-white/5"
            >
              Serviços
            </button>
            <button 
              onClick={() => handleNavClick('#portfolio')} 
              className="text-left py-2 hover:text-white transition-colors border-b border-white/5"
            >
              Portfólio
            </button>
            <button 
              onClick={() => handleNavClick('#diferenciais')} 
              className="text-left py-2 hover:text-white transition-colors border-b border-white/5"
            >
              Diferenciais
            </button>
            <button 
              onClick={() => handleNavClick('#depoimentos')} 
              className="text-left py-2 hover:text-white transition-colors border-b border-white/5"
            >
              Depoimentos
            </button>
            <button 
              onClick={() => handleNavClick('#simulador')} 
              className="text-left py-2 hover:text-white transition-colors border-b border-white/5"
            >
              Simulador de Orçamento
            </button>
            <button 
              onClick={() => handleNavClick('#contato')} 
              className="text-left py-2 hover:text-white transition-colors"
            >
              Contato
            </button>
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
            <a
              href={getWhatsAppUrl('Olá! Gostaria de solicitar um orçamento para criar meu site com a Kairo Studio.')}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full text-center py-3 text-xs font-semibold uppercase tracking-wider text-black bg-white rounded-sm transition-colors flex items-center justify-center gap-2"
            >
              <span>Solicitar Orçamento no WhatsApp</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
