import React, { useState } from 'react';
import { SERVICES, getWhatsAppUrl } from '../data/portfolioData';
import { ArrowUpRight, Check, Zap, Clock, ShieldCheck } from 'lucide-react';

export const Services: React.FC = () => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>('landing-pages');

  const activeService = SERVICES.find((s) => s.id === selectedServiceId) || SERVICES[0];

  return (
    <section id="servicos" className="py-20 md:py-28 border-b border-white/10 bg-[#0c0c10]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest text-neutral-400 uppercase mb-3">
              <span>Soluções Digitais</span>
              <span aria-hidden="true">·</span>
              <span>Criação de Sites para Todos os Nichos</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white max-w-2xl text-balance">
              Serviços pensados para atrair clientes e impulsionar suas vendas
            </h2>
          </div>

          <div className="max-w-md text-sm text-neutral-400">
            Cada projeto combina visual minimalista, código leve e foco em aumentar o faturamento da sua empresa com custo acessível.
          </div>
        </div>

        {/* Services Showcase: Interactive Selector & Deep Dive */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* List of Services on the Left */}
          <div className="lg:col-span-5 space-y-3">
            {SERVICES.map((service) => {
              const isSelected = service.id === selectedServiceId;
              return (
                <button
                  key={service.id}
                  onClick={() => setSelectedServiceId(service.id)}
                  className={`w-full text-left p-5 rounded-lg border transition-all duration-200 cursor-pointer flex items-center justify-between gap-4 ${
                    isSelected
                      ? 'bg-white/10 border-white/30 text-white shadow-lg'
                      : 'bg-white/[0.02] border-white/10 text-neutral-300 hover:bg-white/[0.05] hover:border-white/20'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-xs font-mono font-bold text-neutral-400 mt-0.5">
                      {service.number}.
                    </span>
                    <div>
                      <div className="font-semibold text-base leading-tight">
                        {service.title}
                      </div>
                      <div className="text-xs text-neutral-400 mt-1 line-clamp-1">
                        {service.shortDesc}
                      </div>
                    </div>
                  </div>

                  <span className="text-xs font-medium text-neutral-400 shrink-0 hidden sm:inline">
                    {service.timeline}
                  </span>
                </button>
              );
            })}

            <div className="p-5 rounded-lg bg-white/5 border border-white/10 mt-6">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-white mb-2">
                <Zap className="w-4 h-4 text-white" />
                <span>Precisa de urgência extrema?</span>
              </div>
              <p className="text-xs text-neutral-400 mb-4 leading-normal">
                Dispomos de vaga exclusiva para <strong>Entrega no Mesmo Dia</strong>. Fale conosco pelo WhatsApp para iniciar imediatamente.
              </p>
              <a
                href={getWhatsAppUrl('Olá! Tenho urgência e preciso de um site entregue no mesmo dia. Como podemos começar?')}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-semibold text-white hover:text-neutral-200 underline underline-offset-4 flex items-center gap-1"
              >
                <span>Chamar no plantão de urgência</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Deep Dive Panel on the Right */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-xl silver-card border border-white/15 space-y-8">
              
              <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
                <div>
                  <span className="text-xs font-mono font-semibold text-neutral-400">
                    SERVIÇO {activeService.number}
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-bold text-white mt-1">
                    {activeService.title}
                  </h3>
                </div>
                <div className="px-3 py-1 rounded bg-white/10 border border-white/15 text-xs font-medium text-neutral-200">
                  {activeService.highlight}
                </div>
              </div>

              <div className="space-y-4 text-neutral-300">
                <p className="text-base sm:text-lg leading-relaxed text-white">
                  {activeService.fullDesc}
                </p>
                <div className="text-sm text-neutral-400 pt-2 flex items-center gap-2">
                  <span className="font-semibold text-white">Público recomendado:</span>
                  <span>{activeService.idealFor}</span>
                </div>
                <div className="text-sm text-neutral-400 flex items-center gap-2">
                  <span className="font-semibold text-white">Prazo de entrega:</span>
                  <span className="text-white">{activeService.timeline}</span>
                </div>
              </div>

              {/* Feature Checklist */}
              <div className="space-y-3 pt-6 border-t border-white/10">
                <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  O que está incluso neste desenvolvimento:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {activeService.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-sm text-neutral-200">
                      <Check className="w-4 h-4 text-white shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Banner */}
              <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-neutral-400">Garantia Kairo Studio</div>
                  <div className="text-sm font-semibold text-white">Sem mensalidades ocultas · 100% seu</div>
                </div>

                <a
                  href={getWhatsAppUrl(`Olá! Gostaria de solicitar um orçamento para o serviço: ${activeService.title}.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-black bg-white hover:bg-neutral-200 rounded-sm transition-colors text-center flex items-center justify-center gap-2 shadow-sm"
                >
                  <span>Pedir Orçamento Deste Serviço</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
