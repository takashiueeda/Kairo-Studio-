import React from 'react';
import { STUDIO_CONFIG, getWhatsAppUrl } from '../data/portfolioData';
import { ArrowUpRight, Instagram, Mail, Phone, Download } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050508] border-t border-white/10 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Info */}
          <div className="space-y-4 md:col-span-2">
            <div className="flex items-center gap-2 text-white font-bold text-lg tracking-tight">
              <span className="w-2.5 h-2.5 bg-white rotate-45 shrink-0 inline-block"></span>
              <span>KAIRO STUDIO</span>
            </div>
            <p className="text-neutral-400 text-xs sm:text-sm max-w-sm leading-relaxed">
              {STUDIO_CONFIG.tagline}. Criação de sites modernos, de alta conversão e com entrega no mesmo dia para empresas em todo o Brasil.
            </p>
            <div className="text-neutral-500 text-xs">
              {STUDIO_CONFIG.location}
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-white">
              Navegação
            </div>
            <ul className="space-y-2">
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">Sobre Nós</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Nossos Serviços</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">Portfólio de Projetos</a>
              </li>
              <li>
                <a href="#diferenciais" className="hover:text-white transition-colors">Diferenciais Competitivos</a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">Depoimentos de Clientes</a>
              </li>
              <li>
                <a href="#simulador" className="hover:text-white transition-colors">Simulador de Orçamento</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">Fale Conosco</a>
              </li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-white">
              Contato Direto
            </div>
            <ul className="space-y-2">
              <li>
                <a 
                  href={getWhatsAppUrl('Olá! Vim pelo rodapé do site e gostaria de solicitar um orçamento.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{STUDIO_CONFIG.whatsappNumber}</span>
                  <ArrowUpRight className="w-3 h-3 text-neutral-500" />
                </a>
              </li>
              <li>
                <a 
                  href={STUDIO_CONFIG.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <Instagram className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{STUDIO_CONFIG.instagram}</span>
                  <ArrowUpRight className="w-3 h-3 text-neutral-500" />
                </a>
              </li>
              <li>
                <a 
                  href={`mailto:${STUDIO_CONFIG.email}`}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{STUDIO_CONFIG.email}</span>
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Sub-Footer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-neutral-500 text-[11px]">
          <div>
            © {new Date().getFullYear()} Kairo Studio. Todos os direitos reservados.
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href="/kairo-studio.zip"
              download="kairo-studio.zip"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition-colors text-xs font-medium"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Projeto (.ZIP)</span>
            </a>
            <span aria-hidden="true" className="hidden sm:inline">·</span>
            <span>Design Minimalista em Preto & Prata</span>
            <span aria-hidden="true">·</span>
            <span>Entrega Expressa & Custo-Benefício</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
